/***
 *    author:   kamran_11b

 *    created:  24.07.2018
***/


#include <bits/stdc++.h>
#define ll long long int
using namespace std;

ll strmod(string s, ll n)
{
    ll i, sum = 0;
    for(i=0; i<s.size(); i++)
    {
        sum = sum * 10 + (s[i]-'0');
        sum %= n;
    }
    return sum;
}

int main()
{
    string s;
    ll n;
    cin >> s >> n;
    cout << strmod(s, n) << endl;
    return 0;
}
