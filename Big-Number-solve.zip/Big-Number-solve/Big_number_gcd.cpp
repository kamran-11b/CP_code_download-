/***
 *    author:   kamran_11b

 *    created:  29.05.2018
***/

#include <bits/stdc++.h>
using namespace std;


int main()
{
    int n,t;
    string s;
    cin>>t;
    while(t--)
    {
        cin>>n;
        cin>>s;
        if(n==0)
        {
            cout<<s<<endl;
            continue;
        }
        int m=0;
        for(int i=0; i<s.size(); i++)
        {
            m=((s[i]-'0')+m*10);
            m%=n;
        }
        cout<<__gcd(m,n)<<endl;
    }
}

