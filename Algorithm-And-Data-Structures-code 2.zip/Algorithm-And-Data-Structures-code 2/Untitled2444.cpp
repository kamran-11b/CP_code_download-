#include <stdio.h>

int f(int a, int b)
{
    return a + b;
}
int g(int a, int b)
{
    return a * b;
}

int main()
{
    printf("%d\n�,f(g(2,3),5));
           return 0;
       }
