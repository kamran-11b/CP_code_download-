#include<stdio.h>
#define ll long long
ll mmul(ll A, ll B, ll C)
{
    ll result = 0;
    A %= C;
    while (B)
    {
        if (B % 2)
        {
            result = (result + A) % C;
        }
        A = (A + A) % C;
        B /= 2;
    }
    return result;
}
ll mpow(ll A, ll B, ll C)
{
    ll result = 1;
    A %= C;
    while (B)
    {
        if (B % 2) result = mmul(result, A, C);
        A = mmul(A,A,C);
        B /= 2;
    }
    return result;
}

int main()
{
    int t,i;
    ll A,B,C;
    scanf("%d",&t);
    for(i=1; i<=t; i++)
    {
        scanf("%lld %lld %lld",&A,&B,&C);
        printf("Case %d: %lld\n",i,mpow(A,B,C));
    }

    return 0;
}
