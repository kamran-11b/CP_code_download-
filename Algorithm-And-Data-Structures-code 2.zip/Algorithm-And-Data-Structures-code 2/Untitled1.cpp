#include <iostream>
using namespace std;

int main()
{
    int CT,N,P,S,R;
    while(cin>>CT>>N)
    {
        S=0;
        for(int i=0; i<N; i++)
        {
            cin>>P;
            S+=P;
        }
        R=0;
        if(CT%S==0)
        {
            R=CT/S;
        }
        else
        {
            R=(CT/S)+1;
        }

        if(R==1)
            cout<<"Project will finish within 1 day."<<endl;
        else
            cout<<"Project will finish within "<<R<<" days."<<endl;
    }
    return 0;
}
