#include <stdio.h>

int checkPrimeNumber(int n);
int main()
{
    int n, m, i,flag,t;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d %d", &n, &m);
        for(i=n+1; i<m; ++i)
        {
            flag = checkPrimeNumber(i);
            if(flag == 1)
                printf("%d\n",i);
        }
    }
    printf("\n");
    return 0;
}
int checkPrimeNumber(int n)
{
    int j, flag = 1;

    for(j=2; j <= n/2; ++j)
    {
        if (n%j == 0)
        {
            flag =0;
            break;
        }
    }
    return flag;
}



/*#include <iostream>
#include <bits/stdc++.h>
using namespace std;
int main()
{
    int k=0,t;
    long long int n,m;
    cin>>t;
    for(int c=1; c<=t; c++)
    {
        cin>>n>>m;
        for(int i=n; i<=m; i++)
        {
            k=0;
            for(int j=1; j<=i; j++)
            {
                if(i%j==0)
                {
                    k=k+1;
                    if(k==2 && i==j )
                    {
                        cout<<i<<endl;
                    }
                }

            }

        }
    }
    cout<<" "<<endl;
    return 0;
}



/*
int main()
{
    int t,k,c;
    unsigned int n,m;
    cin>>t;
    for(int j=1; j<=t; j++)
    {
        cin>>n>>m;
        for(k = n; k<=m; k++)
        {
            c = 0;
            for(int i=2; i<=k/2; i++)
            {
                if(k%i==0)
                {
                    c++;
                    break;
                }
            }
            if(c==0 && k!= 1)
                cout<<k<<endl;
        }
        cout<<" "<<endl;
    }
    return 0;
}*/
