#include <iostream>
#include<math.h>
#include<limits.h>

using namespace std;

int main()
{
    int T,N,Q;
    float P;
    long int G;
    cin>>T;
    for(int i=1; i<=T; i++)
    {
        int S=0,D;
        cin>>N;
        while(N--)
        {
            cin>>P>>Q;
            S+=ceil(P*Q);
        }
        cin>>G;
        D=G-S;
        cout <<"Case "<<i<<": "<<D<<endl;
    }
    return 0;
}
