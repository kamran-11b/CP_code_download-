#include<stdio.h>
int main()
{
    unsigned int k,c,p;
    int t;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%u",&k);
        while(1)
        {
            ++k;
            p=k;
            c=0;

            while(p%10 != 0)
            {
                c=(c*10)+(p%10);
                p=p/10;
            }

            if(k == c)
            {
                printf("%u\n",k);
                break;
            }
        }
    }
    return 0;
}
